package com.gim

class SupplierController {

    static scaffold = Supplier
}
