package com.gim

class BarangController {

    static scaffold = Barang
}
