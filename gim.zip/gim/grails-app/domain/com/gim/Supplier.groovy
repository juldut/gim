package com.gim

class Supplier {

	String nama
	String alamat
	String telepon

    static constraints = {
    	nama(maxSize: 50)
    	alamat(sqlType:'text', nullable: true)
    	telepon(maxSize: 25, nullable: true)
    }
}
