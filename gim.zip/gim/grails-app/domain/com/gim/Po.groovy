package com.gim

class Po {

	String nomor
	Supplier supp
	Date tanggal

    static constraints = {
    	nomor(unique: true, maxSize: 25)
    }
}
