package com.gim

class Barang {

	String barcode
	String nama
	String kode
	String keterangan

    static constraints = {
    	nama(maxSize: 50)
    	barcode(maxSize: 30, nullable: true)
    	kode(maxSize: 25, nullable: true)
    	keterangan(sqlType:'text', nullable: true)
    }
}
